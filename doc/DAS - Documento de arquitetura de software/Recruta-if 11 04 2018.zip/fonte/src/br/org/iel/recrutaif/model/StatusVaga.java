package br.org.iel.recrutaif.model;

public enum StatusVaga {
	ATIVA,INATIVA;
}
