package br.org.iel.recrutaif.REST;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("rest")
public class AplicacaoREST extends Application {
	
	
	
	
 
}