package br.org.iel.recrutaif.model;

public enum TipoUsuario {
	CANDIDATO,RECRUTADOR;
}
